# CRM Starter

Simple Next.js + Supabase + Prisma starter for CRM.
