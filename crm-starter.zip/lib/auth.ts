export async function getViewer() {
  return { id: 'demo', role: 'admin' }
}
