export default function Page() {
  return <div><h1>Dashboard</h1><p>Welcome to CRM Starter</p></div>
}
